import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import {menuCard, menuCard2} from "../src/components/menuArray.jsx"
import './index.css'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App  menuCard={menuCard} menuCard2={menuCard2}/>
  </StrictMode>,
)
