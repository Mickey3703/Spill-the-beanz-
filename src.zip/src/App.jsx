import logo from './assets/ChatGPT1.png';
import '../src/css/MenuArray.css';

export default function App({menuCard, menuCard2}) {
  return (
    <div className="main">
      <div className="header">
        <div className="headerLogo">
          <img src={logo} alt="Logo" width="500px" height="400px" />
          <button>Sign up</button>
        </div>
      </div>
<h2>Hot Beverages</h2>
      <div className="content">
        <div className="wholeDivHotBev">
          {menuCard.map((item, index) => (
            <div key={index} className="menu-card">
              <img src={item.img} alt={item.title} />
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <div className="price">
                <p>Small: {item.smallprice}</p>
                <p>Medium: {item.mediumprice}</p>
                <p>Large: {item.largeprice}</p>
              </div>
            </div>
          ))}
        </div>
<h2>Cold Beverages</h2>
        <div className="coldBev">
          {menuCard2.map((item2, index) => (
            <div key={index} className="menu-card">
              <img src={item2.img} alt={item2.title} />
              <h3>{item2.title}</h3>
              <p>{item2.description}</p>
              <div className="price">
                <p>Small: {item2.smallprice}</p>
                <p>Medium: {item2.mediumprice}</p>
                <p>Large: {item2.largeprice}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}